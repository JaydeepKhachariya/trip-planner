import {
  Box,
  Button,
  CardContent,
  Container,
  FormControl,
  InputLabel,
  ListItem,
  MenuItem,
  Modal,
  Select,
  Typography,
} from "@mui/material";
import React, { useEffect, useState } from "react";
import { Navbar } from "../components/Navbar";
import { useParams } from "react-router-dom";
// import { BookingModal } from "../components/BookingModal";
import { Toaster, toast } from "react-hot-toast";
import { getHotelBySlug } from "../api/request";
import { useQuery } from "react-query";
import { plans } from "../helper/Plans";
import {FaLocationDot} from "react-icons/fa6"

const PlanInfo = () => {
    const [open, setOpen] = useState(false);
    const [plan,setPlan]=useState(); 
    const params = useParams();
    const { slug } = params;
    const fetchHoteInfo = () => {
      const plan = plans.filter((plan)=>plan.id==slug)
      console.log(plan[0].image)
      setPlan(plan[0])
      return plan;
    };

    useEffect(()=>{
      fetchHoteInfo();
    },[])
    const handleOpen = () => setOpen(true);
    const handleClose = () => setOpen(false);
    return (
      <>
        <Navbar />
        <main>
          <Container
            maxWidth={"lg"}
            sx={{
              marginTop: 2,
            }}
          >
            <div className="w-full flex items-center justify-between ">
            <Typography fontSize={22} sx={{ lineHeight: 1.9, marginBottom: 3 }}>
              {plan?.name}
            </Typography>
            <Typography fontSize={22} sx={{ lineHeight: 1.9, marginBottom: 3 }}>
              Price : {plan?.price}
            </Typography>
            </div>
            {/* <ImageGallery images={plan?.image} /> */}
            <img
            loading="lazy"
            src={plan?.image}
            style={{ width: "100%", height: "100%" }}
          />
            <Box
              sx={{ display: "flex", marginTop: 2, gap: "0 12px", color: "gray" }}
            >
              {/* {data?.rooms.map((room) => (
                  ))} */}
                <Typography variant="caption" className="flex items-center justify-start gap-2">
                 <FaLocationDot/> {plan?.locations}
                </Typography>
            </Box>
            <Typography fontSize={22} sx={{ lineHeight: 1.9 }}>
              {plan?.plan}
            </Typography>
            <Typography variant="subtitle1">
              {plan?.description}
            </Typography>
            <Box sx={{ marginTop: 2 }}>
              <Typography variant="h5">What this place offers!!</Typography>
              <Box
                sx={{
                  display: "flex",
                  justifyContent: "sace-between",
                  alignItems: "center",
                }}
              >
                {/* <Box sx={{ flex: 1 }}>
                  {data?.features.map((feature) => (
                    <ListItem key={feature.id}>{feature.text}</ListItem>
                  ))}
                </Box> */}
                <CardContent>
                  <Button onClick={handleOpen} variant="outlined">
                    Reserve
                  </Button>
                </CardContent>
              </Box>
            </Box>
          </Container>
        </main>
        <BookingModal hotelInfo={plan} open={open} handleClose={handleClose} />
        <Toaster
          position="top-right"
          toastOptions={{
            duration: 1500,
            style: {
              fontSize: 14,
            },
          }}
        />
      </>
    );
};

export default PlanInfo;


import { Grid} from "@mui/material";
import { LoadingSpinner } from "../components/LoadingSpinner";
import { bookModalStyle } from "../helper/styles";

export const ImageGallery = ({ image }) => {
  return (
    <Grid container spacing={1}>
        <Grid  md={4} xs={12}>
          <img
            loading="lazy"
            src={image}
            style={{ width: "100%", height: "100%" }}
          />
        </Grid>
    </Grid>
  );
};


const BookingModal = ({ open, handleClose, hotelInfo })=>{
   const [guests, setGuests] = useState();
  const [selectedGuestCount, setSelectedGuestCount] = useState(1);
  const [dates, setDates] = useState([
    {
      startDate: new Date(),
      endDate: null,
      key: "selection",
    },
  ]);

  const [isLoading, setIsLoading] = useState(false);

  // const handleChange = (event) => {
  //   setSelectedGuestCount(event.target.value);
  // };

  // function numberOfGuests(maxGuest) {
  //   const guestsArr = [];

  //   for (let i = 1; i <= maxGuest; i++) {
  //     guestsArr.push(i);
  //   }
  //   return guestsArr;
  // }

  // useEffect(() => {
  //   setGuests(numberOfGuests(hotelInfo?.rooms[0]?.content?.split(" ")[0]));
  // }, [hotelInfo]);


    const handleReserve = async () => {
    setIsLoading(true);
    toast.success("booking successfull");
    handleClose();
    navigate('/my-profile')
    setIsLoading(false);
      // .then(() => {
      // })
      // .catch((error) => {
      //   toast.error(error);
      //   setIsLoading(false);
      // });
  };
  return(
     <Modal
      open={open}
      onClose={handleClose}
      aria-labelledby="modal-modal-title"
      aria-describedby="modal-modal-description"
    >
      <Box sx={bookModalStyle}>
        <Typography id="modal-modal-title" variant="h6" component="h2">
          {hotelInfo?.price} price
        </Typography>
        {/* <FormControl fullWidth sx={{ marginTop: 3 }}>
          <InputLabel id="demo-simple-select-label">
            Number of person
          </InputLabel>
          <Select
            labelId="demo-simple-select-label"
            id="demo-simple-select"
            value={selectedGuestCount}
            label="Number of Adults"
            onChange={handleChange}
          >
            {guests?.map((guest) => (
              <MenuItem key={guest} value={guest}>
                {guest}
              </MenuItem>
            ))}
          </Select>
        </FormControl> */}

              <Typography id="modal-modal-title" variant="h6" component="h2"  >{hotelInfo?.date}</Typography>
              <Typography variant="subtitle1">Pickup from : {hotelInfo?.pick_up_point}</Typography>
              <Typography variant="subtitle1">Drop to : {hotelInfo?.drop_point}</Typography>

        {/* <InputLabel>Select Dates</InputLabel>
        <DateRange
          className="date-range"
          editableDateInputs={true}
          onChange={(item) => setDates([item.selection])}
          moveRangeOnFirstSelection={false}
          ranges={dates}
          minDate={new Date()}
        />

        <Box
          sx={{
            display: "flex",
            alignItems: "center",
            justifyContent: "space-between",
            marginY: 2,
          }}
        >
          <Typography
            fontSize={17}
            fontWeight={"bold"}
            component="p"
            variant="h6"
          >
            ${hotelInfo?.price} x{" "}
            {dates[0]?.endDate ? getTotalNightsBooked() : 0} nights
          </Typography>

          <Typography
            fontSize={17}
            fontWeight={"bold"}
            component="p"
            variant="h6"
          >
            $
            {dates[0]?.endDate
              ? hotelInfo?.pricePerNight * getTotalNightsBooked()
              : 0}
          </Typography> */}
        {/* </Box> */}
        <Typography
          fontSize={20}
          fontWeight={"bold"}
          component="p"
          variant="h6"
        >
          Subtotal : {hotelInfo?.price}
        </Typography>
        <Button
          onClick={handleReserve}
          sx={{ width: "100%", marginTop: 2 }}
          variant="outlined"
          color="primary"
        >
          {isLoading ? (
            <LoadingSpinner color={"primary"} size={20} />
          ) : (
            "Reserve"
          )}
        </Button>
      </Box>
    </Modal>
  )
}
