# Hotel Booking WebApp


![thumbnail](https://portfolio-next-js-iota.vercel.app/_next/image?url=%2Fassets%2Fhotelbooking.png&w=1920&q=75)

built with -

1. React.js
2. Firebase
3. Material UI

[Live Demo](https://bookstay.netlify.app/)
