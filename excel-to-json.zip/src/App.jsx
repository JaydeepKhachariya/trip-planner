import React, { useState } from "react";
import * as XLSX from "xlsx";

const App = () => {
  const [inputFile, setInputFile] = useState();
  const [selectedEmployee, setSelectedEmployee] = useState();

  const handleChange = (e) => {
    e.preventDefault();
    if (e.target.files) {
      const reader = new FileReader();
      reader.onload = (e) => {
        const data = e.target.result;
        console.log(data, "data");
        const workbook = XLSX.read(data, { type: "array" });
        const sheetName = workbook.SheetNames[0];
        const worksheet = workbook.Sheets[sheetName];
        const json = XLSX.utils.sheet_to_json(worksheet);
        setInputFile(json);
      };
      reader.readAsArrayBuffer(e.target.files[0]);
    }
  };

  const handleEmployeeSelect = (e) => {
    const employeeId = e.target.value;
    const findEmployee = inputFile.filter((emp) => emp.id === +employeeId);
    console.log(findEmployee[0]);
    setSelectedEmployee(findEmployee[0]);
  };

  const handleDownload = (e) => {
    e.preventDefault();
    console.log(selectedEmployee);
  };

  return (
    <div className="main">
      <form className="form">
        <label htmlFor="uploadfile">Upload excel file </label>
        <input
          onChange={handleChange}
          id="uploadfile"
          type="file"
          placeholder="upload your excel file . . ."
          accept=".csv, application/vnd.openxmlformats-officedocument.spreadsheetml.sheet, application/vnd.ms-excel"
        />
        {inputFile != undefined ? (
          <>
            <label>Select employee</label>
            <select onChange={handleEmployeeSelect}>
              {inputFile.map((employee, i) => {
                return (
                  <option value={employee.id} key={i}>
                    {employee.name}
                  </option>
                );
              })}
            </select>
          </>
        ) : null}
        {selectedEmployee ? (
          <>
            {" "}
            <button onClick={handleDownload}>Download PDF</button>
          </>
        ) : null}
      </form>
    </div>
  );
};

export default App;
